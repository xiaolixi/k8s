
Copyright 2014-2018 Grafana Labs

This software is based on Kibana: 
Copyright 2012-2013 Elasticsearch BV

